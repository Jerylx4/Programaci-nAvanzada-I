package com.prograavanzada.primitivasuno;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Point {
    private final FloatBuffer vertexBuffer; /*Donde se almacenan las coordenadas de los vertices,
                                              pero cuando estan transformados a buffer*/
    private final int mProgram; //Combinacion del vertex con el fragment, controla como se dibuja el objeto
    private int positionHandle, colorHandle; //Son identificadores la ubicacion de la posicion y la ubicacion del color
    static final int coords_per_vertex = 3; //Determinar el numero de coordenadas de cada vertice
    static float pointCoord[]= {0.0f, 0.0f, 0.0f}; //Todos los puntos deben ir almacenados en un arreglo, los vertices que conforman la primivitiva debe ir en un arreglo de flotantes
    private final int vertexCount= pointCoord.length/coords_per_vertex;
    private final int vertexStride= coords_per_vertex*4; //Definir el salo o el desplazamiento que sucede entre cada uno de los vertices
    float color[] = {1.0f, 0.75f, 0.25f, 1.0f};

    public Point(){
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(pointCoord.length*4); //Reservamos en la memoria nativa
        byteBuffer.order(ByteOrder.nativeOrder());
        vertexBuffer = byteBuffer.asFloatBuffer();
        vertexBuffer.put(pointCoord);
        vertexBuffer.position(0);

        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vertexShader);
        GLES20.glAttachShader(mProgram, fragmentShader);
        GLES20.glLinkProgram(mProgram);
    }

    private int loadShader(int type, String shaderCode){
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);

        return shader;
    }

    private final String vertexShaderCode = "";
    private final String fragmentShaderCode= "";

}
