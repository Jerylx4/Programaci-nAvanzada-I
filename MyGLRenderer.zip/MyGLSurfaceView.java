package com.prograavanzada.primitivasuno;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class MyGLSurfaceView extends GLSurfaceView {
    private final MyGLRenderer renderer;


    public MyGLSurfaceView(Context context) {
        super(context);

        //Version de OpenGl ES 2.0
        setEGLContextClientVersion(2);

        //Enlazar el espacio con el constructor
        renderer = new MyGLRenderer();
        setRenderer(renderer);

    }

}
